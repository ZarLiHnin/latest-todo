(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@firebase_auth_dist_esm2017_c2744195._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_c2fcaa2e.js",
  "static/chunks/node_modules_framer-motion_dist_es_1315c24f._.js",
  "static/chunks/node_modules_motion-dom_dist_es_fa3ea29e._.js",
  "static/chunks/node_modules_3806d9b0._.js",
  "static/chunks/_0622989f._.js"
],
    source: "dynamic"
});
