(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@firebase_auth_dist_esm2017_fee4899f._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_c2fcaa2e.js",
  "static/chunks/node_modules_framer-motion_dist_es_1315c24f._.js",
  "static/chunks/node_modules_motion-dom_dist_es_fa3ea29e._.js",
  "static/chunks/node_modules_30373232._.js",
  "static/chunks/_cac7cfa1._.js"
],
    source: "dynamic"
});
