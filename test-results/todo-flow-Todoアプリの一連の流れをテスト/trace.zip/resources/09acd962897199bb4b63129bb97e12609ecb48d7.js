(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_9847dd4a._.js",
  "static/chunks/node_modules_@firebase_auth_dist_esm2017_2ae57f3f._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_c2fcaa2e.js",
  "static/chunks/node_modules_react-day-picker_dist_esm_ed252dcd._.js",
  "static/chunks/node_modules_date-fns_71953021._.js",
  "static/chunks/node_modules_framer-motion_dist_es_1315c24f._.js",
  "static/chunks/node_modules_motion-dom_dist_es_fa3ea29e._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
  "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
  "static/chunks/node_modules_0303cf27._.js"
],
    source: "dynamic"
});
